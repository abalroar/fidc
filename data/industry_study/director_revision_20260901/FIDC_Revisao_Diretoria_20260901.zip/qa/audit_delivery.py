from __future__ import annotations
from pathlib import Path
from zipfile import ZipFile
import hashlib, json, re
import pandas as pd
from PIL import Image, ImageChops
from lxml import etree

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parents[1]
BASE=OUT/'bases'
FULL=OUT/'Industria_FIDC_Completa_Revisada_20260901.pptx'
COMPACT=OUT/'FIDC_Revisao_Diretoria_20260901.pptx'
SOURCE=ROOT/'data/industry_study/director_revision_20260827/Industria_FIDC_Completa_Revisada_20260827.pptx'
OLD_RENDER=ROOT/'data/industry_study/director_revision_20260827/Industria_FIDC_Completa_Revisada_20260827'
NEW_RENDER=OUT/'Industria_FIDC_Completa_Revisada_20260901'
A='{http://schemas.openxmlformats.org/drawingml/2006/main}'
P='{http://schemas.openxmlformats.org/presentationml/2006/main}'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def text_of(z,name):
    root=etree.fromstring(z.read(name))
    return ' '.join(t.text or '' for t in root.iter(A+'t'))

stock=pd.read_csv(BASE/'saldo_cenarios.csv')
pf=pd.read_csv(BASE/'pfpj_24_incluidos.csv',dtype={'cnpj_fundo':str})
dec=pd.read_csv(BASE/'pfpj_26_decisoes.csv',dtype={'cnpj_fundo':str})
issue=pd.read_csv(BASE/'emissoes_por_categoria.csv')
audit=pd.read_csv(BASE/'emissoes_auditoria.csv')
latest=stock[(stock.competencia=='2026-06')&(stock.cenario=='sem_tapso_petrobras')]

checks={
 'pfpj_24_fundos':len(pf)==24,
 'decisoes_26':len(dec)==26,
 'exclusoes_11_26':set(dec.loc[~dec.incluir_pfpj.astype(bool),'ordem'].astype(int))=={11,26},
 'pfpj_pl':abs(pf.pl_brl_base.sum()-7102640442.08)<.01,
 'stock_total':abs(latest.pl_brl.sum()-718610541429.85)<.02,
 'financeiro':abs(latest.loc[latest.categoria=='Financeiro','pl_brl'].iloc[0]-275294471988.64)<.02,
 'stock_share':abs(latest.share.sum()-1)<1e-9,
 'issue_share':issue.groupby('period_key').share.sum().sub(1).abs().max()<1e-9,
 'issue_pfpj_1s26':abs(issue.loc[(issue.period_key=='jun26')&(issue.categoria=='Multicarteira Pulverizado PF/PJ'),'volume_brl'].iloc[0]-2603000000.07)<.01,
 'issue_fic_1s26':abs(audit.loc[audit.period_key=='jun26','fic_excluido_brl'].iloc[0]-2813379549.06)<.01,
}
for name,path,count in [('full',FULL,39),('compact',COMPACT,3)]:
    with ZipFile(path) as z:
        slides=[n for n in z.namelist() if re.fullmatch(r'ppt/slides/slide\d+\.xml',n)]
        checks[name+'_slide_count']=len(slides)==count
        alltext=' '.join(text_of(z,n) for n in slides)
        for phrase in ['Itaú e Kanastra separados','Sólido e BizCapital','Top1','taxonomia congelada']:
            checks[name+'_'+phrase]=phrase.casefold() in alltext.casefold()
        notes=' '.join(text_of(z,n) for n in z.namelist() if re.fullmatch(r'ppt/notesSlides/notesSlide\d+\.xml',n))
        checks[name+'_sources_notes']='[Sources]' in notes
with ZipFile(SOURCE) as a, ZipFile(FULL) as b:
    themes=[n for n in a.namelist() if n.startswith('ppt/theme/')]
    checks['themes_preserved']=all(a.read(n)==b.read(n) for n in themes)

changed=[]
for i in range(1,40):
    a=Image.open(OLD_RENDER/f'slide-{i}.png').convert('RGB')
    b=Image.open(NEW_RENDER/f'slide-{i}.png').convert('RGB')
    if ImageChops.difference(a,b).getbbox():
        changed.append(i)
checks['only_expected_slides_changed']=changed==[4,5,6,34,38,39]
checks['overflow_full']='Test passed' in (OUT/'qa/overflow_apresentacao_completa.txt').read_text()
checks['overflow_compact']='Test passed' in (OUT/'qa/overflow_laminas.txt').read_text()
checks={k:bool(v) for k,v in checks.items()}
if not all(checks.values()):
    raise SystemExit({k:v for k,v in checks.items() if not v})
result={
 'status':'pass',
 'checks':checks,
 'changed_slides':changed,
 'full_sha256':sha(FULL),
 'compact_sha256':sha(COMPACT),
 'source_sha256':sha(SOURCE),
 'pfpj_pl_brl':float(pf.pl_brl_base.sum()),
 'stock_total_sem_tapso_petrobras_brl':float(latest.pl_brl.sum()),
 'financeiro_sem_tapso_petrobras_apos_pfpj_brl':float(latest.loc[latest.categoria=='Financeiro','pl_brl'].iloc[0]),
 'issuance_pfpj_jan_jun_2026_brl':float(issue.loc[(issue.period_key=='jun26')&(issue.categoria=='Multicarteira Pulverizado PF/PJ'),'volume_brl'].iloc[0]),
}
(OUT/'qa/auditoria_entrega.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False,indent=2))
